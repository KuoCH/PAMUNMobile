// Jump to desktop version of website if client is not mobile device
if(! /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) {
  window.location="http://www.panasiamun.com/";
}
